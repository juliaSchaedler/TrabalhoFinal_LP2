<?php

use Application\core\Controller;

class Critica extends Controller
{
  /**
  * chama a view index.php da seguinte forma /user/index   ou somente   /user
  * e retorna para a view todos os usuários no banco de dados.
  */
  public function index()
  {
    $Criticas = $this->model('Criticas'); // é retornado o model Users()
    $data = $Criticas::findAll();
    $this->view('critica/index', ['criticas' => $data]);
  }

  /**
  * chama a view show.php da seguinte forma /user/show passando um parâmetro 
  * via URL /user/show/id e é retornado um array contendo (ou não) um determinado
  * usuário. Além disso é verificado se foi passado ou não um id pela url, caso
  * não seja informado, é chamado a view de página não encontrada.
  *    $id   Identificado do usuário.
  */

  public function cadastrarCritica(){
    $idUser = $_GET['idUser'];
    $idFilme = $_GET['idFilme'];
    $comentario = $_GET['comentario'];
    $nota = $_GET['nota'];


    $Criticas = $this->model('Criticas'); // é retornado o model Users()
    $data = $Criticas::insertData($idUser, $idFilme, $comentario, $nota);
    $this->view('critica/index');

  }




  public function show($id = null)
  {
    if (is_numeric($id)) {
      $Criticas = $this->model('Criticas');
      $data = $Criticas::findById($id);
      $this->view('critica/show', ['critica' => $data]);
    } else {
      $this->pageNotFound();
    }
  }


}