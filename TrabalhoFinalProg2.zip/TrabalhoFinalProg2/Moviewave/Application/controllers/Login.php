<?php

use Application\core\Controller;

class Login extends Controller{

    public function logar(){
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $User = $this->model('Users');
        $data = $User::findByEmailAndPassword($email, $senha);
        // print_r($data);

        if (empty($data)) {
            $this->view('login/index');
            echo "Usuário ou senha inválido";
        } else {
            echo "Usuário logado com sucesso";
            $this->view('home/index');
        }
    }


    public function cadastrar(){
        $nome = $_GET['nome'];
        $email = $_GET['email'];
        $senha = $_GET['senha'];

        $User = $this->model('Users');
        $data = $User::insertData($nome, $email, $senha);




    }
}

?>




