<?php

namespace Application\models;

use Application\core\Database;
use PDO;
class Users
{
  /** Poderiamos ter atributos aqui */

  /**
  * Este método busca todos os usuários armazenados na base de dados
  *
  * @return   array
  */
  public static function findAll()
  {
    $conn = new Database();
    $result = $conn->executeQuery('SELECT * FROM usuarios');
    return $result->fetchAll(PDO::FETCH_ASSOC);
  }

  /**
  * Este método busca um usuário armazenados na base de dados com um
  * determinado ID
  * @param    int     $id   Identificador único do usuário
  *
  * @return   array
  */
  public static function findById(int $id)
  {
    $conn = new Database();
    $result = $conn->executeQuery('SELECT * FROM usuarios WHERE id = :ID LIMIT 1', array(
      ':ID' => $id
    ));

    return $result->fetchAll(PDO::FETCH_ASSOC);
  }

  public static function findByEmailAndPassword(string $email, string $senha){
    $conn = new Database();
    $comando = $conn->executeQuery('SELECT * FROM usuarios WHERE email = :EMAIL AND senha= :SENHA LIMIT 1', array(
      ':EMAIL' => $email,
      ':SENHA' => $senha
    ));

    return $comando->fetchAll(PDO::FETCH_ASSOC);

  }

  public static function insertData(string $nome, string $email, string $senha){
    $conn = new Database();
    $comando = $conn -> executeQuery('INSERT INTO usuarios (nome, email senha) VALUES (:NOME, :EMAIL, :SENHA)', array(
      ':NOME' => $nome,
      ':EMAIL' =>$email,
      ':SENHA' =>$senha
    ));

    return $comando->fetchAll(PDO::FETCH_ASSOC);

  }

}
