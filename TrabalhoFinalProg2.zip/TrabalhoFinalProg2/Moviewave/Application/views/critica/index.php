
<link rel="stylesheet" href="/assets/css/critica.css">



                    <!------------- MENU -------------->

                    <!------------- BANNER -------------->
  <section class="banner">
			<h1>Críticas</h1>
			<p class="b">O melhor lugar para registrar suas impressões de filmes!</p>
  </section>

                    <!------------- FORMULARIO -------------->
  <section class="formulario">
		<div class="maior">
      
			<div class="texto">
				<h2>Registre suas críticas!</h2>
				<h3>Utilize o formulário ao lado:</h3>
				<p>Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu. Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu. Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu. Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu.</p>
				<p class="botao"><a href="#">Leia mais</a></p>
			</div>
      
			<div class="formu">
				<p>Qual sua crítica?</p>
				<form>
					<input type="text" name="usuario" id="usuario" placeholder="Usuário">
					<input type="text" name="idF" id="idF" placeholder="Id do Filme">
					<br>

					<input type="text" name="nomeF" id="nomeF" placeholder="nome do filme">
					<input type="text" name="anoL" id="anoL" placeholder="Ano de Lançamento">
					<br>

					<input type="text" name="genero" id="genero" placeholder="Genêro">
					<input type="text" name="diretor" id="diretor" placeholder="Diretor">
					<br>
					<input class="cv" type="critica" name="critica" id="critica" placeholder="Crítica">
          <input type="text" name="nota" id="nota" placeholder="Nota">

				</form>
				<p class="botao2"><a href="#">ENVIAR</a></p>
			</div>
		</div>		
  </section>
  
                      <!------------- ULTIMAS CRITICAS -------------->
  <section class="ultimasCriticas">
    <h1>Ultimas críticas</h1>
    <div class="container">
    <div class="row">
      <div class="col-8 offset-2" style="margin-top:100px">
        <h2>criticas</h2>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Nome Usuário</th>
              <th scope="col">id Filme</th>
              <th scope="col">Comentário</th>
              <th scope="col">Nota</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($data['criticas'] as $critica) ?>
            <tr>
              <td><?= $critica['idUser'] ?></td>
              <td><?= $critica['idFilme'] ?></td>
              <td><?= $critica['comentario'] ?></td>
              <td><?= $critica['nota'] ?></td>
              
            </tr>
            <?php ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  </section>
                                                           
                      <!------------- RODAPÉ -------------->
                                                           


