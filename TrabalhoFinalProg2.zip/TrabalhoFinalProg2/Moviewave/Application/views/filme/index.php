

<link rel="stylesheet" href="/assets/css/filme.css">
  

<!------------------- BANNER  ---------------->

<section class="banner">
  <h1>Filmes</h1>
  <p class="b">Confira os últimos lançamentos para registrar suas críticas!</p>
</section>

                <!------------- FORMULARIO ---------------->

<section class="formulario">
  <div class="maior">
    
    <div class="texto">
      <h2>Registre suas críticas!</h2>
      <h3>Utilize o formulário ao lado:</h3>
      <p>Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu. Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu. Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu. Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu.</p>
      <p class="botao"><a href="#">Leia mais</a></p>
    </div>
    
    <div class="formu">
      <p>Insira o filme:</p>
      <form>
        <input type="text" name="idF" id="idF" placeholder="Id do Filme">
        <br>

        <input type="text" name="nomeF" id="nomeF" placeholder="nome do filme">
        <input type="text" name="anoL" id="anoL" placeholder="Ano de Lançamento">
        <br>

        <input type="text" name="genero" id="genero" placeholder="Genêro">
        <input type="text" name="diretor" id="diretor" placeholder="Diretor">
        <br>
        <input class="cv" type="critica" name="critica" id="critica" placeholder="Crítica">
        <input type="text" name="nota" id="nota" placeholder="Nota">

      </form>
      <p class="botao2"><a href="#">ENVIAR</a></p>
    </div>
  </div>		
</section>

                  <!------------ ULTIMOS FILMES CADASTRADOS ------------------->

<section class="ultimosFilmes">
  <h1>Ultimos Filmes</h1>
  <div class="container">
  <div class="row">
    <div class="col-8 offset-2" style="margin-top:100px">
      <h2>Filmes</h2>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Nome</th>
            <th scope="col">Ano de lançamento</th>
            <th scope="col">Genêro</th>
            <th scope="col">Diretor</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($data['filmes'] as $filme)  ?>
          <tr>
            <td><?= $filme['nome'] ?></td>
            <td><?= $filme['anoLancamento'] ?></td>
            <td><?= $filme['genero'] ?></td>
            <td><?= $filme['diretor'] ?></td>             
          </tr>
          <?php ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</section>

