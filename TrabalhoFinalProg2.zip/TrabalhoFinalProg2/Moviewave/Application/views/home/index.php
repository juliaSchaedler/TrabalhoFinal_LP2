<html lang="en">
  <head>
    <title>Moviewave</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/reset.css">
    <link rel="stylesheet" href="assets/css/login.css">
  </head>
  
  <body>

    <section class="banner">
			<h2>MOVIEWAVE</h2>
			<p class="b">O melhor site de críticas de filmes</p>
			<p><a href="#">Cadastra-se</a></p>
    </section>
  

	  <section class="criticaFilme">
      <h1>Registre:</h1>

      <div class="criticaFilme">
        <div class="critica">
          <h2>Críticas</h2>
          <p>Acabou de assistir um filme e quer deixar sua review? Escolha o filme em questão e registre sua nota!</p>
          <p><a href="#">Registre sua críticas</a></p>
        </div>
      
      <div class="filme">
        <h2>Filmes</h2>
        <p>Foi registrar sua critíca mas não tinha o filme em questão? Nos ajude a atualizar nosso site colocando novos filmes!</p>
        <p><a href="#">Registre um filme</a></p>
      </div>
    </div>   
  </section>
  </body>
</html>