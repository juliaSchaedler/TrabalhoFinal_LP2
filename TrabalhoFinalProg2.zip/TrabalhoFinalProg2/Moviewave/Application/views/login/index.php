
  <link rel="stylesheet" href="assets/css/login.css">

  
                <!--------------- MENU  ----------------->

  <section class="login">
    <div class="maior">
      
			<div class="login">
				<p>Faça login:</p>
				<form action="/login/logar" method="POST">
					<input type="text" name="email" id="email" placeholder="Email">
					<br>

					<input type="password" name="senha" id="senha" placeholder="Senha">
					<br>

                    <input type="submit" value="ENVIAR">
				</form>
			</div>

      <h2>OU</h2>
      
			<div class="cadastro">
				<p>Insira os dados para cadastro:</p>
				<form action="..\Application\controllers\Login.php" method="POST">
					<input type="text" name="nome" id="nome" placeholder="Nome">
					<br>

					<input type="text" name="email" id="email" placeholder="Email">
					<br>

					<input type="password" name="senha" id="senha" placeholder="Senha">
					<br>
                    
                    <input type="submit" value="ENVIAR">
				</form>
			</div>
		</div>		
  </section>

                      <!------------ RODAPE  ------------>
  
  <!-- page content -->

