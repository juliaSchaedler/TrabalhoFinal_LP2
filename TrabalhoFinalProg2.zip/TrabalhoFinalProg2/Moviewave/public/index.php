<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>Moviewave</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/assets/css/reset.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    
    
    
  </head>
  <body>
    <header>	
      <nav>
        <h1><a href="#"><img src="/assets/img/logoGato.png" alt="logo"></a></h1>

        <ul>
          <li><a href="home">Home</a></li>
          <li><a href="filme">Filmes</a></li>
          <li><a href="critica">Críticas</a></li>
          <li><a href="#">Sobre nós</a></li>
          <li><a href="#">Contato</a></li>
          <li><a href="login">Log in</a></li>
        </ul>
      </nav>
	</header>

  <?php
    require '../Application/autoload.php';

    use Application\core\App;
    use Application\core\Controller;

    $app = new App();

  ?>

  <?php 
    /*$url = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
    if($url == "/login"){
      require_once(__DIR__."\\..\\Application\\views\\login\\index.php");
      return;
    }*/
  ?>

  


	<section class="RodaPe">
		<div class="maior3">
			<div class="quadro1">
				<h2>Sobre Moviewave</h2>
				<div class="linha"></div>
				<p>Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu. Quisuqe sollicitudin feugiat risus, eu posuere ex euismod eu.</p>
				<ul>
					<li><img src="/assets/img/facebook.png"></li>
					<li><img src="/assets/img/twitter.png"></li>
					<li><img src="/assets/img/instagram.png"></li>
				</ul>
			</div>

			<div class="quadro3">
				<h2>Contato</h2>
				<p><img src="/assets/img/placeholder.png"> +123, Main Street, Your City, New York USA 789456</p>
				<p><img src="/assets/img/telefone.png">+123 4567 8900</p>
				<p><img src="/assets/img/arroba.png">free@psdfreebies.com</p>
				<p><img src="/assets/img/internet.png">www.psdfreebies.com</p>
			</div>
		</div>
	</section>
	<footer>
		<p>Copyright c 2022</p>
	</footer>
  <!-- page content -->

<script src="js/jquery-3.3.1.min.js"></script>
<script>window.jQuery || document.write('<script src="js/vendor/jquery-3.2.1.min.js"><\/script>')</script>
  <script src="/assets/js/jquery.slim.min.js"></script>
  <script src="/assets/js/bootstrap.min.js"></script>
  </body>
</html>
