create table usuarios (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    nome text not null,
    email text not null,
    senha text not null
);

insert into usuarios (nome, email, senha) values ("Fulano", "fulano@gmail.com", "12345");
insert into usuarios (nome, email, senha) values ("Miguel", "miguel.menna2@gmail.com", "hampter");

insert into filmes (nome, anoLancamento, genero, diretor) values ("Duna", 2021, "Ficção científica", "Denis Villeneuve");
insert into filmes (nome, anoLancamento, genero, diretor) values ("A viagem de Chihiro", 2001, "Animação", "Hayao Miyazaki");

insert into criticas (idUser, idFilme, comentario, nota) values (1, 1, "Filme espetacular, com certeza melhor que o antecessor!", 10);
insert into criticas (idUser, idFilme, comentario, nota) values (1, 2, "Animação muito boa de assistir, história incrível, queria apenas que o final fosse diferente!", 9);


select * from usuarios;
select * from filmes;
select * from criticas;